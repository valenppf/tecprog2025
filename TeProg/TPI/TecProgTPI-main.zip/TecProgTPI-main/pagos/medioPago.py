class MedioPago:
    # DEFINIR LA INTERFAZ
    def __init__(self):
        pass